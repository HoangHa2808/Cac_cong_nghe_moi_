import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, NavController } from '@ionic/angular';
import { Account } from '../model/account';
import { AccountService } from '../services/account.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  email: string = '';
  password: string = '';

  accounts: Account[] = [];

  constructor(
    private router: Router,
    private accountService: AccountService,
    private alertController: AlertController
  ) {}

  async ngOnInit(): Promise<void> {
    this.accounts = await this.accountService.getAccounts();
  }

  async addAccount() {
    await this.accountService.addAccount(this.email, this.password);
    this.accounts = await this.accountService.getAccounts();
    this.email = this.password = '';

    await (
      await this.alertController.create({
        header: 'Hệ thống ATM',
        subHeader: 'Thêm tài khoản',
        message: 'Tài khoản đã được thêm thành công',
        buttons: ['OK'],
      })
    ).present();

    this.accounts = await this.accountService.getAccounts();
  }

  async removeAccount(): Promise<void> {
    const deleted = await this.accountService.deleteAccount(this.email);
    if (!deleted) {
      await (
        await this.alertController.create({
          header: 'Hệ thống ATM',
          subHeader: 'Xoá tài khoản',
          message: 'Tài khoản chưa được xoá',
          buttons: ['OK'],
        })
      ).present();
      return;
    }

    await (
      await this.alertController.create({
        header: 'Hệ thống ATM',
        subHeader: 'Xoá tài khoản',
        message: 'Tài khoản đã được xoá thành công',
        buttons: ['OK'],
      })
    ).present();

    this.accounts = await this.accountService.getAccounts();
  }

  async login() {
    if (!this.email || !this.password) return;

    const isLoggedIn = await this.accountService.login(
      this.email,
      this.password
    );
    if (isLoggedIn) {
      this.router.navigate(['/home']);
    } else {
      await (
        await this.alertController.create({
          header: 'Hệ thống ATM',
          subHeader: 'Đăng nhập',
          message:
            'Đăng nhập không thành công. Vui lòng kiểm tra lại email và password.',
          buttons: ['OK'],
        })
      ).present();
    }
  }

  async viewAllAccounts() {
    const accounts = this.accounts
      .map(
        (acc) => `${acc.email}: pass(${acc.password}) - money: ${acc.money}\n`
      )
      .join('');

    await (
      await this.alertController.create({
        header: 'Hệ thống ATM',
        subHeader: 'Tất cả tài khoản hiện tại',
        message: accounts || 'Không có tài khoản nào!',
        buttons: ['OK'],
      })
    ).present();

    this.accounts = await this.accountService.getAccounts();
  }
}
