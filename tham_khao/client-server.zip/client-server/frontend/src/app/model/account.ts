export interface Account{
    email: string;
    password: string;
    money: number;
}