import { Storage } from '@ionic/storage';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class Data {
  constructor(private storage: Storage){
    this.getData().then((data: any) => {
      console.log(data); // This will contain the checklists
    });
  }
  getData(): any {
    return this.storage.get('checklists');
  } 
  save(data: any): void {
    this.storage.set('checklists', data);
  }
}