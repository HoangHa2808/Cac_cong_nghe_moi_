import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../services/account.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage {
  email: string = '';
  money: number = 0;

  posts = null;

  constructor(
    private router: Router,
    private accountService: AccountService,
  ) {
  }

  async ionViewWillEnter() {
    // Retrieve the data from the service
    this.email = (await this.accountService.getCurrentAccount())?._email ?? "";
    this.money = (await this.accountService.getCurrentAccount())?._money ?? 0;
  }

  viewInfo() {
    // Redirect to home page and pass loginInfo as state
    this.router.navigate(['/view-info']);
  }

  logout() {
    this.accountService.logout();

    // Redirect to home page and pass loginInfo as state
    this.router.navigate(['/login']);
  }

  takePicture() {
    // Redirect to home page and pass loginInfo as state
    this.router.navigate(['/camera']);
  }
  Map() {
    this.router.navigate(['/map']);
  }

}
