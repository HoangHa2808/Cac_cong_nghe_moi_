import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountService } from '../services/account.service';

@Component({
  selector: 'app-view-info',
  templateUrl: './view-info.page.html',
  styleUrls: ['./view-info.page.scss'],
})
export class ViewInfoPage implements OnInit {
  email: string = "";
  money: number = 0;

  constructor(private route: ActivatedRoute, private accountService: AccountService) { }

  async ngOnInit() {
    // const routeSnapshot: ActivatedRouteSnapshot = this.route.snapshot;

    // this.email = routeSnapshot.params['email'] ?? "";
    // this.money = +(routeSnapshot.params['money'] ?? 0);

    this.email = (await this.accountService.getCurrentAccount())?._email ?? "";
    this.money = (await this.accountService.getCurrentAccount())?._money ?? 0;

  }
}
