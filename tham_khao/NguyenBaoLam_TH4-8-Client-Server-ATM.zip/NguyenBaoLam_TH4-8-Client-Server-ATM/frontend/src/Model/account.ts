export interface Account {
    _id: string;
    _email: string;
    _password: string;
    _money: number;
}