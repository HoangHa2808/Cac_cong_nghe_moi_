const fs = require('fs');
const path = require('path');

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const morgan = require('morgan');

const Account = require('./models/account');

const app = express();

const accessLogStream = fs.createWriteStream(
  path.join(__dirname, 'logs', 'access.log'),
  { flags: 'a' }
);

app.use(morgan('combined', { stream: accessLogStream }));

app.use(bodyParser.json());

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.get('/accounts', async (req, res) => {
  console.log('TRYING TO FETCH ACCOUNTS');
  try {
    const accounts = await Account.find();
    res.status(200).json({
      accounts: accounts.map((account) => ({
        _id: account.id,
        _email: account.email,
        _password: account.password,
        _money: account.money,
      })),
    });
    console.log('FETCHED ACCOUNTS');
  } catch (err) {
    console.error('ERROR FETCHING ACCOUNTS');
    console.error(err.message);
    res.status(500).json({ message: 'Failed to load accounts.' });
  }
});

app.post('/accounts', async (req, res) => {
  console.log('TRYING TO STORE ACCOUNT');
  const accountEmail = req.body._email ?? '';
  const accountPass = req.body._password ?? '';
  const accountMoney = req.body._money;

  if (!accountEmail || accountEmail.trim().length === 0 ||
    !accountPass || accountPass.trim().length === 0) {
    console.log('INVALID INPUT');
    return res.status(422).json({ message: 'Invalid account.' });
  }

  const account = new Account({
    email: accountEmail,
    password: accountPass,
    money: accountMoney,
  });

  try {
    await account.save();
    res
      .status(201)
      .json({
        message: 'Account saved', account: {
          _id: account.id,
          _email: accountEmail,
          _password: accountPass,
          _money: accountMoney,
        }
      });
    console.log('STORED NEW ACCOUNT');
  } catch (err) {
    console.error('ERROR FETCHING ACCOUNTS');
    console.error(err.message);
    res.status(500).json({ message: 'Failed to save account.' });
  }
});

app.delete('/accounts/:email/:password', async (req, res) => {
  console.log('TRYING TO DELETE ACCOUNT');
  try {
    const resp = await Account.deleteOne({ email: req.params.email, password: req.params.password });
    res.status(resp.deletedCount > 0 ? 200 : 401).json({ message: 'Deleted account!' });
    console.log('DELETED ACCOUNT');
  } catch (err) {
    console.error('ERROR FETCHING ACCOUNTS');
    console.error(err.message);
    res.status(500).json({ message: 'Failed to delete account.' });
  }
});

mongoose.connect(
  // `mongodb://${process.env.MONGODB_USERNAME}:${process.env.MONGODB_PASSWORD}@mongodb:27017/course-accounts?authSource=admin`,
  `mongodb://0.0.0.0:27017/course-accounts`,
  // `mongodb://host.docker.internal:27017/course-accounts`,
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  (err) => {
    if (err) {
      console.error('FAILED TO CONNECT TO MONGODB');
      console.error(err);
    } else {
      console.log('CONNECTED TO MONGODB!!');
      app.listen(80);
    }
  }
);
