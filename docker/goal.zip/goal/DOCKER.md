<!-- 2-41 -->
"C:\Program Files\Docker\Docker\Docker Desktop.exe"
"C:\Program Files\Docker\Docker\Docker Desktop.exe"
<section>
    <h2><img src="img/system/topic-xl.png" id="heading-text-image">&nbsp;&nbsp;Triển khai Docker</h2>
    <ul>

    .dockerignore
        node_modules
        Dockerfile
        .git

        <li>Tạo image và container
            <pre data-cc="false"><code data-trim class="shell" id="cmd-1-source">
            $ docker build -t goal-image .
            $ docker images
            $ -- chạy container in attached mode (show console log)
            $ docker run --name goal-app -p 80:80 goal-image
            $ http://localhost
            </code></pre>
        </li>
        <li>Mở Terminal mới (+), 
            <pre data-cc="false"><code data-trim class="shell" id="cmd-1-source">
            $ -- ngưng chạy container
            $ docker stop goal-app
            $ docker ps -a
            $ -- chạy lại container in detached mode
            $ docker start goal-app
            $ docker ps
            $ -- container run in foreground with dif port and detached mode
            $ docker run --name goal-app -d -p 8000:80 goal-image
            $ -- view log data
            $ docker logs -f goal-app

            $ -- start again in attached mode
            $ docker start -a goal-app

            $ -- start again in attached mode with interactive (python eg.)
            $ docker start -a -i goal-app

            </code></pre>
        </li>
        <li>Handle container and image, 
            <pre data-cc="false"><code data-trim class="shell" id="cmd-1-source">
            $ -- remove container after exit
            $ docker run --name goal-app -d --rm -p 8000:80 goal-image

            $ -- inspect image
            $ docker image inspect goal-image

            $ -- copy containers
            $ \docker\goal\
            $    > dummy
                      test.txt -> 'Hello'
            $ docker cp dummy/. goal-app:/test
            $ docker cp dummy/test.txt goal-app:/test
            $ docker cp goal-app:/test new-dummy


            $ -- create free account ('hoang12345', pw: 'phan12345') in Docker Hub
            $ -- https://hub.docker.com/signup
            $ -- 'Create a repository'
            $ -- create public repository ('goal') in Docker Hub
            $ docker push hoang12345/goal:tagname

            $ -- share images
            $ docker tag goal-image:latest hoang12345/goal:latest
            $ docker images

            $ docker login
            $ docker push hoang12345/goal:latest

            $ -- use images
            $ docker image prune -a
            $ docker images

            $ docker logout
            $ docker pull hoang12345/goal:latest
            $ -- search and run automatically images
            $ docker run hoang12345/goal:latest

            $ docker images
            $ docker run --rm -p 8000:80 hoang12345/goal:latest

            </code></pre>
        </li>
    </ul>
</section>